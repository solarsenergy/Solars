<?php
/**
 * Основные параметры WordPress.
 *
 * Скрипт для создания wp-config.php использует этот файл в процессе
 * установки. Необязательно использовать веб-интерфейс, можно
 * скопировать файл в "wp-config.php" и заполнить значения вручную.
 *
 * Этот файл содержит следующие параметры:
 *
 * * Настройки MySQL
 * * Секретные ключи
 * * Префикс таблиц базы данных
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** Параметры MySQL: Эту информацию можно получить у вашего хостинг-провайдера ** //
/** Имя базы данных для WordPress */
define('DB_NAME', 'solars');

/** Имя пользователя MySQL */
define('DB_USER', 'root');

/** Пароль к базе данных MySQL */
define('DB_PASSWORD', '');

/** Имя сервера MySQL */
define('DB_HOST', 'localhost');

/** Кодировка базы данных для создания таблиц. */
define('DB_CHARSET', 'utf8mb4');

/** Схема сопоставления. Не меняйте, если не уверены. */
define('DB_COLLATE', '');

/**#@+
 * Уникальные ключи и соли для аутентификации.
 *
 * Смените значение каждой константы на уникальную фразу.
 * Можно сгенерировать их с помощью {@link https://api.wordpress.org/secret-key/1.1/salt/ сервиса ключей на WordPress.org}
 * Можно изменить их, чтобы сделать существующие файлы cookies недействительными. Пользователям потребуется авторизоваться снова.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         '1yZ:wFHU1?p7F9+:B&N3KeprvQ^N{&lDa30FqP>7+XnZlK*95w-m:7lnq):>%`]i');
define('SECURE_AUTH_KEY',  '7+XvA#/H,kFikU|llHB2GthI+*7`[V ybnY6 J0lM>:=m7]IKSEN5SE4v$3bQ4*6');
define('LOGGED_IN_KEY',    '.WsI*X{{wR}^feavDJ<Z=W5=z]a4vx^ZPFF,WcM]2-x&ULk.*JF01dKm n0LZbt7');
define('NONCE_KEY',        '^L=9|z`kg(%775h@-3C4Be~kE7YO6S}kFM@s&oRu>v`6IG*:tz,P#=rhkXl|OF2?');
define('AUTH_SALT',        'R.VXr8_w?!%a2d{{fm<tjhq@DiD<$*h@dT6WhLzIa&ed~AtY.aqu5*%K|,#;Fn11');
define('SECURE_AUTH_SALT', '*DA[/#S4[BdTA~+X4LQLNPIR}P[9Q44WOx{P[%L>>fE#[Rr0y})ge(ne@w(4E{uB');
define('LOGGED_IN_SALT',   '2-!wcZc02slbWZ%6^I+Fjn;xrboCrm7@wCG,3s|`/Na;9]^,!LNs=j^$,5i%B}dY');
define('NONCE_SALT',       'X|l~BkrP3[e~~D3Jpqo>C:[73eip`A(zWE<oe_|=BPj/w5N8g6>7x)k.ee!-_V[s');

/**#@-*/

/**
 * Префикс таблиц в базе данных WordPress.
 *
 * Можно установить несколько сайтов в одну базу данных, если использовать
 * разные префиксы. Пожалуйста, указывайте только цифры, буквы и знак подчеркивания.
 */
$table_prefix  = 'wp_';

/**
 * Для разработчиков: Режим отладки WordPress.
 *
 * Измените это значение на true, чтобы включить отображение уведомлений при разработке.
 * Разработчикам плагинов и тем настоятельно рекомендуется использовать WP_DEBUG
 * в своём рабочем окружении.
 *
 * Информацию о других отладочных константах можно найти в Кодексе.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define('WP_DEBUG', false);

/* Это всё, дальше не редактируем. Успехов! */

/** Абсолютный путь к директории WordPress. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Инициализирует переменные WordPress и подключает файлы. */
require_once(ABSPATH . 'wp-settings.php');
